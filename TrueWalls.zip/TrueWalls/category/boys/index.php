<?php

include_once '../../includes/dbh.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $_GET['cat'];?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
	  rel="stylesheet">
      <link rel="stylesheet" href="css/bootstrap.min.css">
       <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.0/css/bulma.min.css">
    
</head>
<body>

<nav class="navbar is-fixed-top" style="background-color: #ffffff;">
  <a class="navbar-brand" href="../../"><i class="material-icons">arrow_backward</i><span id="title"></span></a>
  

 
</nav><br><br><br>

<div class="container">

<h1 style="font-size: 85px;text-transform:uppercase;"><?php echo $_GET['cat'];?></h1><br>
<p style="font-weight: lighter;color:#888282;"> Total Photos: 


	<?php

$cat=$_GET['cat'];
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>

</p><br>
    <!--Grid row-->
<div class="row">

<!--Grid column-->
<?php
        $keyword = "%{$_GET['cat']}%";
        $sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt,$sql)) {
        echo "Statement Error!";
        }
        else
        {
        mysqli_stmt_bind_param($stmt,"s",$keyword);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $rowcount = mysqli_num_rows($result);
        if ($rowcount > 0) {
        
          while($row = mysqli_fetch_assoc($result))
        {
        echo '<div class="col-lg-4 col-md-12 mb-4">
        
        
        <div class="card">
          <img src="../../includes/walls/'. $row['imgFullName'].'" class="card-img-top">
          <div class="card-body">
          <p class="subtitle">Size: ';echo $row['size'];echo'Mb</p>
          <p class="subtitle">Resolution: ';echo $row['Res'];echo'</p>
          <p class="subtitle">Uploaded by: ';echo $row['personGallery'];echo'</p>
          <button class="button is-primary is-rounded"><i class="material-icons">file_download</i></button>
        </div>
      </div>
          
          
          </div>
        
        ';
        }}
        else
        {
        header('location:../../404.php');
        exit();
        }
        }
        ?>
</div>
<!--Grid row-->
</div>



<script src="js/jquery-3.4.1.min.js"></script>

<script>
$(document).ready(function()
{
  $(window).scroll(function(){
  	var scroll = $(window).scrollTop();
	  if (scroll > 110) {
	    $(".nav").css("box-shadow" , "0px 2px 10px 0px rgba(0,0,0,0.65)");
      $('#title').html('BOYS');
	  }
    

	  else{
		$(".nav").css("box-shadow" , "0px 0px 0px 0px rgba(0,0,0,0.65)"); 
    $('#title').html('');	
	  }
  });
});
</script>



<script src="js/bootstrap.min.js"></script>
<script src="js/popper.min.js"></script>
</body>
</html>