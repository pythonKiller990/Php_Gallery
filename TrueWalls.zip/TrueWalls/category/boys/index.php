<?php

include_once '../../includes/dbh.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $_GET['cat'];?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
	  rel="stylesheet">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
    
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light nav fixed-top" style="background-color: #ffffff;">
  <a class="navbar-brand" href="../../"><i class="material-icons">arrow_backward</i></a>
  

 
</nav><br><br><br>

<div class="container">

<h1 style="font-size: 85px;text-transform:uppercase;"><?php echo $_GET['cat'];?></h1><br>
<p style="font-weight: lighter;color:#888282;"> Total Photos: 


	<?php

$cat=$_GET['cat'];
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>

</p><br>
    <!--Grid row-->
<div class="row">

<!--Grid column-->
<?php
        $keyword = $_GET['cat'];
        $sql = "SELECT * FROM galleryExamp WHERE Category LIKE ? ORDER BY Category ASC";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt,$sql)) {
        echo "Statement Error!";
        }
        else
        {
        mysqli_stmt_bind_param($stmt,"s",$keyword);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $rowcount = mysqli_num_rows($result);
        if ($rowcount > 0) {
        
        while($row = mysqli_fetch_assoc($result))
        {
        echo '<div class="col-lg-4 col-md-12 mb-4">
        
        
          <a href="#modal'.$row['orderGallery'].'" class="modal-trigger">
          <img src="../../includes/walls/'. $row['imgFullName'].'" class="img-fluid mb-4 gallery"></a>
          
          
          </div>
        
        ';
        }}
        else
        {
        header('location:../../404.php');
        exit();
        }
        }
        ?>
</div>
<!--Grid row-->
</div>



<script src="js/jquery-3.4.1.min.js"></script>

<script>
$(document).ready(function()
{
  $(window).scroll(function(){
  	var scroll = $(window).scrollTop();
	  if (scroll > 20) {
	    $(".nav").css("box-shadow" , "0px 2px 10px 0px rgba(0,0,0,0.65)");
	  }

	  else{
		$(".nav").css("box-shadow" , "0px 0px 0px 0px rgba(0,0,0,0.65)"); 	
	  }
  });
});
</script>



<script src="js/bootstrap.min.js"></script>
<script src="js/popper.min.js"></script>
</body>
</html>