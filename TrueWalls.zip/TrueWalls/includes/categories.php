<!--Categories-->
<section class="section" id="collections">

<div class="container">
    <!--<h1 class="is-size-1">Collections</h1>-->
    <div class="columns">
        

<div class="column">
<a href="category/Abstracts/?cat=Abstracts">
<div class="box first">
  <p class="title" style="color: #fff;">Abstracts</p>
  <p class="subtitle"><?php

$cat="%abstracts%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> photos</p>

</div></a>
</div>
<div class="column">
<a href="category/Girls/?cat=Girls">
<div class="box second">
  <p class="title" style="color: #fff;">Girls</p>
  <p class="subtitle">  <?php

$cat="%girls%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> Photos</p>

</div>
</a>
</div>
<div class="column">
<a href="category/Animals/?cat=Animals">
<div class="box third">
  <p class="title" style="color: #fff;">Animals</p>
  <p class="subtitle"><?php

$cat="%animals%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> photos</p>

</div>
</a>
</div>
<div class="column">
<a href="category/Boys/?cat=Boys">
<div class="box fourth">
  <p class="title" style="color: #fff;">Boys</p>
  <p class="subtitle"><?php

$cat="%boys%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> photos</p>

</div>
</a>
</div>
</div>
<div class="columns">
        

<div class="column">
<a href="category/Beaches/?cat=Beaches">
<div class="box fifth">
  <p class="title" style="color: #fff;">Beachs</p>
  <p class="subtitle"><?php

$cat="%beaches%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> photos</p>

</div>
</a>
</div>
<div class="column">
<a href="category/Portraits/?cat=Portraits">
<div class="box sixth">
  <p class="title" style="color: #fff;">Portraits</p>
  <p class="subtitle"><?php

$cat="%portraits%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> photos</p>

</div>
</a>
</div>
<div class="column">
<a href="category/Technology/?cat=Technology">
<div class="box seventh">
  <p class="title" style="color: #fff;">Technology</p>
  <p class="subtitle"><?php

$cat="%technology%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> photos</p>

</div>
</a>
</div>
<div class="column">
<a href="category/Architectures/?cat=Architectures">
<div class="box eighth">
  <p class="title" style="color: #fff;">Architectures</p>
  <p class="subtitle"><?php

$cat="%architectures%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> photos</p>

</div>
</a>
</div>
</div>
<div class="columns">
        

<div class="column">
<a href="category/Kids/?cat=Kids">
<div class="box ninth">
  <p class="title" style="color: #fff;">Kids</p>
  <p class="subtitle"><?php

$cat="%kids%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> photos</p>
</div>
</a>
</div>
<div class="column">
<a href="category/Mountains/?cat=Mountains">
<div class="box tenth">
  <p class="title" style="color: #fff;">Mountains</p>
  <p class="subtitle">
<?php

$cat="%mountains%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> photos</p>

</div>
</a>
</div>
<div class="column">
<a href="category/Flowers/?cat=Flowers">
<div class="box eleventh">
  <p class="title" style="color: #fff;">Flowers</p>
  <p class="subtitle"><?php

$cat="%flowers%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> photos</p>

</div>
</a>
</div>
<div class="column">
<a href="category/Cars/?cat=Cars">
<div class="box twelth">
  <p class="title" style="color: #fff;">Cars</p>
  <p class="subtitle"><?php

$cat="%cars%";
$sql = "SELECT * FROM galleryExamp WHERE title LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;

?> photos</p>

</div>
</a>
</div>
</div>
</div>

</section>