<!--footer-->
<section class="hero is-primary footer">
  	<div class="container">
  		<div class="columns">
  			<div class="column">
  				<h5 class="title is-size-3">TrueWalls</h5>
  				<p class="subtitle is-size-5">Get Free High Ressolution Images for Free for Websites & Commercial Use.</p>
  			</div>
  			

  			<div class="column">
  				<h5 class="title is-size-3">Devloper Profiles</h5>
  				
				<ul>
  					<li><a class="button is-primary is-rounded"><i class="fab fa-facebook"></i></a></li>
  					<li><a class="button is-primary is-rounded"><i class="fab fa-instagram"></i></a></li>
  					<li><a class="button is-primary is-rounded"><i class="fab fa-linkedin"></i></a></li>
  				</ul>
  			</div>

  		</div>
  	</div>
  	
  </section>