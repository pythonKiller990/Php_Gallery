<section class="hero is-fullheight" id="hero" style="background-color: #1d1d1d;">
    <div class="hero-body hero-body-padding-large">
    <div class="container">

      <h1 class="title first-head is-size-1">
        Free stock Photos for websites and commercial use.
      </h1>
      <h2 class="subtitle">
        Download free,high resolution images.
      </h2>
      <div class="container">
      	<div class="columns">
      		<div class="column">
      			<br><br><br>

    <div class="container">
    	<div class="columns">
    		<div class="column">
    			<form class="control has-icons-right" action="search/" method="GET">
  <div class="field">
 
  
    <input class="input is-large is-outlined" type="text" placeholder="Search Photos" style="outline: none;" name="key" autocomplete="off">
    <span class="icon is-small is-right">
      <i class="fas fa-search"></i>
    </span>
</div>
	</form>
	<br> 
    		</div>
    	</div>
    </div>
      		</div>
      	</div>
      </div>
    </div>
  </div>
  </section>