<?php session_start(); ?>

<?php
include_once 'includes/dbh.php';
$fullname = "";
$img = "";
$user = "";
$email="";
if (isset($_SESSION['username'])) {
	$user = $_SESSION['username'];
	}

	$sql = "SELECT * FROM users WHERE userid = ?";
	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt,$sql)) {
	echo "Statement Error!";
	}
	else
	{
	mysqli_stmt_bind_param($stmt,"s",$user);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	if ($row = mysqli_fetch_assoc($result)) {
	$fullname = $row['fname'];
	$img = $row['avatar'];
	$userid = $row['userid'];
	$email=$row['email'];
	}
	}


function getEmail()
{
	return $GLOBALS['email'];
}


function theme()
{
$userTheme = $GLOBALS['theme'];
return $userTheme;
}
function userImage()
{
$image = $GLOBALS['img'];
return $image;
}
function userName()
{
$name = $GLOBALS['fullname'];
return $name;
}
function userid()
{
$uid = $GLOBALS['userid'];
return $uid;
}
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>TrueWalls-Home</title>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
	  rel="stylesheet">
	  <link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
 <body>
<nav class="navbar navbar-expand-lg navbar-light nav fixed-top" style="background-color: #ffffff;">
  <a class="navbar-brand" href="#">TrueWalls</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
	  <?php
	  if(!isset($_SESSION['username']))
	  {
		  echo '<li class="nav-item">
		  <a class="nav-link" href="login/">Login</a>
		</li>';
	  }
	  ?>
	  <?php
	  if(isset($_SESSION['username']))
	  {
		  echo '<li class="nav-item">
		  <a class="nav-link" href="upload.php">Upload</a>
		</li>';
		echo '<li class="nav-item"><a class="nav-link" href="#" data-toggle="modal" data-target="#profile">';

		echo 'Your Profile'.'</a></li>';

		
	  }
	  ?>
	  
	  
      
      
    </ul>
  
  </div>
</nav><br><br><br><br><br><br>

<div class="container">



<br><br>
<h1 align="center">CATEGORIES</h1><br><br><br><br>
<!--Grid row-->
<div class="row">

<!--Grid column-->
<div class="col-lg-4 col-md-12 mb-4">

  <img src="img/girls.jpeg" class="img-fluid mb-4 circled" alt="Girl Category cover not loaded">
  <p align="center"><a href="category/girls/index.php?cat=girls" class="btn" style="background-image:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Girls  Total: 

  <?php

$cat="girls";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>
</a></p>

  <img src="img/flowers.jpeg" class="img-fluid mb-4 circled" alt=""
	data-wow-delay="0.3s">
	<p align="center"><a href="category/flowers/index.php?cat=flowers" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Flowers Total: 


	<?php

$cat="flowers";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>

</a></p>

</div>
<!--Grid column-->

<!--Grid column-->
<div class="col-lg-4 col-md-6 mb-4">

  <img src="img/boys.jpeg" class="img-fluid mb-4 circled" alt=""
	data-wow-delay="0.1s">
	<p align="center"><a href="category/boys/index.php?cat=boys" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Boys Total: 

	<?php

$cat="boys";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>
</a></p>

  <img src="img/cars.jpeg" class="img-fluid mb-4 circled" alt=""
	data-wow-delay="0.4s">

	<p align="center"><a href="category/cars/index.php?cat=cars" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Cars Total: 
	<?php

$cat="cars";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>

</a></p>

</div>
<!--Grid column-->

<!--Grid column-->
<div class="col-lg-4 col-md-6 mb-4">

  <img src="img/mountains.jpeg" class="img-fluid mb-4 circled" alt=""
	data-wow-delay="0.2s">

	<p align="center"><a href="category/mountains/index.php?cat=mountains" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Mountains Total: 

	<?php

$cat="mountains";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>
</a></p>

  <img src="img/kids.jpeg" class="img-fluid mb-4 circled" alt=""
	data-wow-delay="0.5s">

	<p align="center"><a href="category/kids/index.php?cat=kids" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Kids Total: 

	<?php

$cat="kids";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>
</a></p>

</div>
<!--Grid column-->

</div>
<!--Grid row-->



<!--Grid row-->
<div class="row">

<!--Grid column-->
<div class="col-lg-4 col-md-12 mb-4">

  <img src="img/technology.jpeg" class="img-fluid mb-4 circled" alt="">

  <p align="center"><a href="category/technology/index.php?cat=technology" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Technology Total:
  <?php

$cat="technology";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>
</a></p>

  <img src="img/beaches.jpeg" class="img-fluid mb-4 circled" alt=""
	data-wow-delay="0.3s">

	<p align="center"><a href="category/beaches/index.php?cat=beaches" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Beaches Total: 
	<?php

$cat="beaches";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>
</a></p>

</div>
<!--Grid column-->

<!--Grid column-->
<div class="col-lg-4 col-md-6 mb-4">

  <img src="img/animals.jpeg" class="img-fluid mb-4 circled" alt=""
	data-wow-delay="0.1s">

	<p align="center"><a href="category/animals/index.php?cat=animals" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Animals Total: 

	<?php

$cat="animals";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>
</a></p>

  <img src="img/architectures.jpeg" class="img-fluid mb-4 circled" alt=""
	data-wow-delay="0.4s">

	<p align="center"><a href="category/architectures/index.php?cat=architectures" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Architectures Total: 

	<?php

$cat="architectures";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>
</a></p>

</div>
<!--Grid column-->

<!--Grid column-->
<div class="col-lg-4 col-md-6 mb-4">

  <img src="img/portraits.jpeg" class="img-fluid mb-4 circled" alt=""
	data-wow-delay="0.2s">

	<p align="center"><a href="category/portraits/index.php?cat=portraits" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Portraits Total: 

	<?php

$cat="portraits";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>
</a></p>

  <img src="img/abstracts.jpeg" class="img-fluid mb-4 circled" alt=""
	data-wow-delay="0.5s">

	<p align="center"><a href="category/abstracts/index.php?cat=abstracts" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:65px;color:#fff;font-size:18px;">Abstracts Total: 
	<?php

$cat="abstracts";
$sql = "SELECT * FROM galleryExamp WHERE Category LIKE ?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt,$sql)) {
echo "Statement Error!";
}
else
{
mysqli_stmt_bind_param($stmt,"s",$cat);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$count =mysqli_num_rows($result);
}
echo $count;
  
  ?>
</a></p>

</div>
<!--Grid column-->

</div>


	


</div>



<?php
if(isset($_SESSION['username']))
{
	echo '<!-- Modal -->
	<div class="modal fade" id="profile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
		<div class="modal-content" style="border-radius:10px;height:500px;width:350px;text-align:center;">
		  
		  <div class="modal-body">
			';

			echo '<img src="../True/includes/avatar/';echo userImage();echo '" style="width:100px;height:100px;border-radius:50%;position:relative;top:30%;left:15%;transform:translate(-50%,-50%);"><br><br><br><br><br><strong style="font-weight:lighter;outline:none;" id="name" contenteditable="true">';
			echo userName();

			echo'</strong><input type="hidden" value="';echo $_SESSION['username'];echo'" id="username"><br>
			<strong id="email" contenteditable="true" style="outline:none;">';
			echo getEmail();echo'</strong><br><br>
			<a type="button" class="btn" style="background:linear-gradient(45deg,#F40E8A,#E20F95,#5E14EB);border-radius:50%;color:#fff;font-size:12px;padding-top:10px;padding-left:10px;padding-right:10px;width:50px;height:50px;text-align:center;" href="login/logout.php"><i class="material-icons">exit_to_app</i></a>
			<a type="button" class="btn" style="background-color:#EFBE65;border-radius:50%;color:#fff;font-size:12px;padding-top:10px;padding-left:10px;padding-right:10px;width:50px;height:50px;text-align:center;" id="edit"><i class="material-icons">edit</i></a>
		  </div>
		 
		</div>
	  </div>
	</div>';
}

?>



<script src="js/jquery-3.4.1.min.js"></script>



<script src="js/bootstrap.min.js"></script>
<script src="js/popper.min.js"></script>

<script>


$(document).ready(function(){
  $(window).scroll(function(){
  	var scroll = $(window).scrollTop();
	  if (scroll > 20) {
	    $(".nav").css("box-shadow" , "0px 2px 10px 0px rgba(0,0,0,0.65)");
	  }

	  else{
		$(".nav").css("box-shadow" , "0px 0px 0px 0px rgba(0,0,0,0.65)"); 	
	  }
  });

  $('#first').tooltip();


  $('#edit').on('click',function()
  {

	  

	$.ajax({
			url: "update.php",
			type: "POST",
			cache: false,
			data:{
				
				name: $('#name').html(),
				email: $('#email').html(),
				uname:$('#username').val()
			},
			success: function(dataResult){
				var dataResult = JSON.parse(dataResult);
				if(dataResult.statusCode==200){
					
					
					$('#profile').modal('toggle');
				    location.reload(true);
										
				}
				else if(dataResult.statusCode==201)
				{
					console.log('Database Error!');
				}
			}
		});

  });
  
});



</script>

	
</body>
</html>