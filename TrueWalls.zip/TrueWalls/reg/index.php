<?php

if(isset($_SESSION['username']))
{
    header('location:../index.php');
    exit();
}

else
{
    if (isset($_POST['reg'])) {
        require '../includes/dbh.php';
        
    
        $fullname = $_POST['name'];
        $email = $_POST['email'];
        $pass1 = $_POST['password1'];
        $pass2 = $_POST['password2'];
        $userid = $_POST['uname'];
        
    
        //echo $fullname ." email : ".$email." pass1 : ".$pass1. " pass2 : ".$pass2." userid: ".$userid;
    
        $randNo = rand(1,4);
    
    
        
        $imageFullName = "avatar".$randNo."."."png";
        
        $hashedPass= md5($pass1);
        
    
    
        //check for empty fields 
    
    
        if (empty($fullname)  || empty($email) || empty($pass1) || empty($pass2) || empty($userid)) {
            echo 'empty fields';
            exit();
        }
        
        
        else if ($pass1 !== $pass2) {
            echo "Two Password Not Matched!";
            exit();
        }
    
        else
        {
            //check already registred username in database
            $sql = "SELECT userid FROM users WHERE userid=?";
    
            $stmt = mysqli_stmt_init($conn);
    
            if (!mysqli_stmt_prepare($stmt,$sql)) {
                echo "statement Error";
                exit();
            }
            else
            {
                mysqli_stmt_bind_param($stmt,"s",$userid);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);
                $resultCheck = mysqli_stmt_num_rows($stmt);
    
                if ($resultCheck > 0) {
                    echo "user already taken!";
                    exit();
                }
                else
                {
    
                    $sql = "INSERT INTO users(fname,userid,email,upass,avatar)VALUES(?,?,?,?,?);";
                    $stmt = mysqli_stmt_init($conn);
                    if (!mysqli_stmt_prepare($stmt,$sql)) {
                        echo 'statement error2!';
                        exit();
                    }
                    else
                    {
                          mysqli_stmt_bind_param($stmt,"sssss",$fullname,$userid,$email,$hashedPass,$imageFullName);
                          mysqli_stmt_execute($stmt);
                          //move_uploaded_file($fileTempName,$directory);
                          
                    }
    
    
                }
            }
        }
    
        
    
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    }


}


    





?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>TrueWalls-Home</title>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
	  rel="stylesheet">
	  <link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light nav fixed-top" style="background-color: #ffffff;">
  <a class="navbar-brand" href="../"><i class="material-icons">arrow_backward</i></a>
  

 
</nav><br><br><br><br>
<p align="center">

<div class="main">



        <h1>Create Account</h1>


<p align="center">
<form action="" method="POST" autocomplete="off">
            <input type="text" placeholder="Enter Full Name" id="input1" autocomplete="off" name="name">
            <input type="text" placeholder="Enter Username Name" id="input2" autocomplete="off" name="uname">
            <input type="email" placeholder="Enter Email" id="input3" autocomplete="off" name="email">
            <input type="password" placeholder="Create Password" id="pass1" autocomplete="off" name="password1"><br>
            <input type="password" placeholder="Confirm Password" id="pass2" autocomplete="off" name="password2">
            <input type="submit" value="Create Acoount" class="btn" name="reg">
        </form>
</p>
        
    </div>
</p>






<script src="js/jquery-3.4.1.min.js"></script>



<script src="js/bootstrap.min.js"></script>
<script src="js/popper.min.js"></script>



	
</body>
</html>