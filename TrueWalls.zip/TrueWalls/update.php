<?php
$server = 'localhost';
$username = 'root';
$password = "";
$dbname = "gallery";

$conn = mysqli_connect($server,$username,$password,$dbname);
	$name=$_POST['name'];
    $uname=$_POST['uname'];
    $email=$_POST['email'];
	
	$sql = "update users set fname='$name', email='$email' where userid='$uname'";
	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn);




?>