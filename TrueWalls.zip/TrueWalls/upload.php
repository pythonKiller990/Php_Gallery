<?php
session_start();

if(!isset($_SESSION['username']))
{
    header('location:index.php');
    exit();
}

include_once 'includes/dbh.php';
$fullname = "";
$img = "";
$user = "";
$theme="";
$email="";
if (isset($_SESSION['username'])) {
	$user = $_SESSION['username'];
	}

	$sql = "SELECT * FROM users WHERE userid = ?";
	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt,$sql)) {
	echo "Statement Error!";
	}
	else
	{
	mysqli_stmt_bind_param($stmt,"s",$user);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	if ($row = mysqli_fetch_assoc($result)) {
	$fullname = $row['fname'];
	$userid = $row['userid'];
	
	}
	}

function userName()
{
$name = $GLOBALS['fullname'];
return $name;
}
function userid()
{
$uid = $GLOBALS['userid'];
return $uid;
}
    






//check is upload button is clicked
if (isset($_POST['upload'])) {
	
//get another data
	$category = $_POST['category'];
	$personName = userName();
	$uid = userid();
	$file = $_FILES['file'];
	$image_info = getimagesize($_FILES["file"]["tmp_name"]);
    $image_width = $image_info[0];
    $image_height = $image_info[1];
    $res=$image_width." x ".$image_height;
	//echo $title;
	//echo $desc;
	//echo $personName;
	//print_r($file);
	$filename = $file['name'];
	//print($filename);
	$fileType = $file['type'];
	$fileTempName = $file['tmp_name'];
	//echo $fileTempName;
	$fileError = $file['error'];
	$fileSize = $file['size'];
	$fileSize = round($fileSize / 1024 / 1024, 1);
	echo $fileSize;
	$fileExtension = explode(".",$filename);
	$fileActualExt = strtolower(end($fileExtension));
	$allowedExt = array("jpg","jpeg","png");

	if($category=="")
	{
		header('location:upload.php?message=Choose a category first!');
		exit();
	}
	else
	{
	
	if (in_array($fileActualExt, $allowedExt)) {
		if ($fileError == 0) {
			# code...
			if ($fileSize < 20000000000) {
				//echo "Good size";
				$imageFullName = "TrueWalls".$filename . ".".uniqid("",true).".".$fileActualExt;
				//echo $imageFullName;
				$directory = "includes/walls/".$imageFullName;
				//echo $directory;
				include_once 'includes/dbh.php';
//check for empty fields
				
					$sql = "SELECT * FROM galleryExamp";
					$stmt = mysqli_stmt_init($conn);
					//check for any statement error
					if (!mysqli_stmt_prepare($stmt,$sql)) {
						echo "Statement error!1";
						exit();
					}
					else
					{
						mysqli_stmt_execute($stmt);
						$result = mysqli_stmt_get_result($stmt);
						$rowCount = mysqli_num_rows($result);
						$setImageOrder = $rowCount + 1;
						$sql = "INSERT INTO galleryExamp(Category,personGallery,imgFullName,orderGallery,userid,Res,size)VALUES(?,?,?,?,?,?,?);";
						if (!mysqli_stmt_prepare($stmt,$sql)) {
							echo "Statement Error2";
							exit();
						}
						else
						{
							
							mysqli_stmt_bind_param($stmt,"sssssss",$category,$personName,$imageFullName,$setImageOrder,$uid,$res,$fileSize);
							mysqli_stmt_execute($stmt);
							move_uploaded_file($fileTempName,$directory);
							header("location:upload.php?message='Photo Added Go Back!'");
						}
					}
				
				
			}
			else
			{
				echo "There is an error!";
			}
		}
		else
		{
			echo "upload error!";
			exit();
		}
		
	}
	else
	{
		header('location:upload.php?message=Wrong Type File or You forget to Add Image');
		exit();
	}
}
	
	
}





?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TrueWalls-uploads</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
	  rel="stylesheet">
	  <link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light nav fixed-top" style="background-color: #ffffff;">
  <a class="navbar-brand" href="index.php"><i class="material-icons">arrow_backward</i></a>
  
</nav><br><br><br><br><br>

<div class="container">
    <h1>Choose an Image & Category to upload</h1>
    <form action="" method="POST" enctype="multipart/form-data">

   

    <input type="file" name="file" id="file"><br><br><br>

    <select name="category" style="outline: none;">
      <option value=""  selected>Choose a Category</option>
      <option value="Girls">Girls</option>
      <option value="Flowers">Flowers</option>
      <option value="Boys">Boys</option>
       <option value="Technology">Technology</option>
        <option value="Beaches">Beaches</option>
         <option value="Cars">Cars</option>
          <option value="Animals">Animals</option>
          <option value="Mountains">Mountains</option>
          <option value="Kids">Kids</option>
		  <option value="Portraits">Portraits</option>
		  <option value="Abstracts">Abstracts</option>
    </select>

    <input type="submit" value="Upload" name="upload">



    </form><br><br><br><br>
    <h1 align="center"><?php if(isset($_GET['message']))
    {
       echo $_GET['message']; 
    }?></h1>
</div>
    
</body>
</html>